var app = getApp();
Page({
  data: {
    isHaveAddress: false,
    isHaveCoupons: false,
    addressInfo: null,
    allPrice: 0,//总共需要支付的价格
    shoplist:[]
  },
  onLoad: function () {
    var that = this
    wx.request({
      url: 'http://47.106.227.33/xejz-api/api.php?op=storeslist',
      headers: {
        'Content-Type': 'application/json'
      },
      
      success: function (res) {
        console.log(res.data)
        that.setData({
          shoplist:res.data.result
        })
        console.log(that.data.shoplist)
      }
    })
  },
  gotoshangjia:function(e) {
    var id=e.currentTarget.id
    console.log(id)
    wx.navigateTo({
      url: '../../pages/dianjia/dianjia?bid='+id,
    })
  },
  onReady: function () {
    // 页面渲染完成
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
    getApp().globalData.otherAddressInfo = null;
  },
})