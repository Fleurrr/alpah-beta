// pages/zixuan/onpay.js
Page({
  data: {
    list: [], // 数据列表
    a: null,
    isHaveAddress: false,
    isHaveCoupons: false,
    addressInfo: null,
    allPrice: 0,//总共需要支付的价格
  },

  allShopPrice: function () {
    var shopList = this.data.List;
    var shopPrice = 0.0;
    console.log(shopList)
    for (var key in shopList) {
      console.log(key)
      shopPrice += shopList[key].class_price
    }
    this.setData({
      allPrice: shopPrice,
    });
  },

  onItemClick: function (e) {
    var index = e.currentTarget.dataset.itemIndex;
    wx.navigateTo({
      url: '../../pages/shopinfo/shopinfo?id=' + e.currentTarget.dataset.itemIndex,
    })
  },

  goToPay: function () {
    wx.requestPayment({
      timeStamp: 'String1',
      nonceStr: 'String2',
      package: 'String3',
      signType: 'MD5',
      paySign: 'String4',
      success: function (res) {
        wx.showToast({
          title: '成功',
          icon: 'success',
          duration: 2000
        })
      },
      fail: function () {
        wx.showToast({
          title: '失败',
          icon: 'success',
          duration: 2000
        })
      },
      complete: function () {
        // complete
      }
    })
  },

  backtochoose: function () {
    wx.navigateTo({
      url: '../../pages/zixuan/zixuan',
    })
  },
  onLoad: function (options) {
    console.log(options)
    var _this = this;
    var json = JSON.parse(options.result)
    console.log(json)
    _this.setData({
      list: json
    })
    // console.log(_this.data.list)
    console.log("yes")
    var shopList = json;
    var shopPrice = 0;
    console.log(shopList)
    for (var key in shopList) {
      console.log(Number(shopList[key].class_price))
      shopPrice += Number(shopList[key].class_price)
    }
    console.log(shopPrice)
    _this.setData({
      allPrice: shopPrice,
    });
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
    var otherAddressInfo = getApp().globalData.otherAddressInfo;
    if (otherAddressInfo == null) {
      var addressList = wx.getStorageSync('address');
      for (var key in addressList) {
        if (addressList[key].isDefult) {
          this.setData({
            addressInfo: addressList[key],
            isHaveAddress: true,
          });
        }
      }
      if (this.data.addressInfo == null && addressList.length > 0) {
        this.setData({
          addressInfo: addressList[0],
          isHaveAddress: true,
        });
      }
    } else {
      this.setData({
        addressInfo: otherAddressInfo,
        isHaveAddress: true,
      });
    }

  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
    getApp().globalData.otherAddressInfo = null;
  },
  onShareAppMessage: function () {
    return {
      title: '我的购物车',
      desc: '好多好多东西，没钱了',
      path: 'www.baidu.com'
    }
  }



})