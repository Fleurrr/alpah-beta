var app = getApp();
Page({
  data: {
    address: "定位中...",
    location: {
      0: {
        id: 0,
        name: "紫荆园",
        latitude: 26.0527250710,
        longitude: 119.1920846701,
      },
      1: {
        id: 1,
        name: "玫瑰园",
        latitude: 26.0529323024,
        longitude: 119.1927820444,
      }
    },
    latitude: null,
    longitude: null,

    placeholder: "请输入店名",
    searchWords: "",
    shoplist:"",

  },
  inputSearch: function (e) {
    this.setData({
      searchWords: e.detail.value
    });
  },
  doSearch: function () {
    var that = this
    var value = this.data.searchWords
    wx.request({
      url: 'http://47.106.227.33/xejz-api/api.php?op=searchb&value='+value,
      headers: {
        'Content-Type': 'application/json'
      },

      success: function (res) {
        that.setData({
          shoplist: res.data.result
        })
        console.log(that.data.shoplist)
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.getLocation({
      success: function (res) {
        type: 'wgs84'
        console.log(res)
        var latitude = res.latitude
        var longitude = res.longitude
        var o = that.data.location
        var min = 1
        var mid = 0
        for (var key in o) {
          console.log(key)
          var x = o[key].latitude - latitude
          var y = o[key].longitude - longitude

          if (x * x + y * y < min) {
            min = x * x + y * y
            mid = key
          }
        }
        console.log(mid)
        that.setData({
          address: o[mid].name
        })
      },
    }) 

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})