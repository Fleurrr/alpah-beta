//index.js
//获取应用实例
var app = getApp();
var swiperIndex =  0;
var QQMapWX = require('../../utils/qqmap-wx-jssdk.js');
var qqmapsdk;
Page({
  data: {
    indicatorDots: "true",//是否显示面板指示点
    autoplay: "true",//是否自动切换
    interval: "5000",//自动切换时间间隔
    duration: "1000",//滑动动画时长
    address:"定位中...",
    weizhi:'',
    placeholder:"请输入店名",
    searchWords:"",
    imgUrls: [
      "../../img/1.png",
      "../../img/2.png",
      "../../img/3.png"
    ],
    shoplist:[],
  },

//点击轮播图
  swiperClick : function(){
   

  },
  tozixuan: function () {
    

  },

  inputSearch: function (e) {
    this.setData({
      searchWords: e.detail.value
    });
  },
  doSearch: function () {
   var value=this.data.searchWords
   wx.navigateTo({
      url:"/pages/searchresult/searchresult"
   })
  },


//轮播图轮播事件
  swiperChange: function (e) {   
      swiperIndex =  e.detail.current
  },


  onLoad: function (options) {
    var that=this
    qqmapsdk = new QQMapWX({
      key: 'KTWBZ-WGE6P-YWYDT-VFDWG-4PPSH-3TBLO'
    });
    wx.request({
      url: 'http://47.106.227.33/xejz-api/api.php?op=storeslist',
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        console.log("ok1")
        console.log(res.data)
        that.setData({
          shoplist: res.data.result
        })
        console.log(that.data.shoplist)
      }
    })
  },
  gotoshangjia: function (e) {
    var id = e.currentTarget.id
    console.log(id)
    wx.navigateTo({
      url: '../../pages/dianjia/dianjia?bid=' + id,
    })
  },
  onReady: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        console.log(res)
        var latitude1 = res.latitude
        var longitude1 = res.longitude
        qqmapsdk.reverseGeocoder({
          location: {
            latitude: latitude1,
            longitude: longitude1
          },
          success: function (res) {
            console.log(res);
            var add = res.result.address
            var address = add.substring(6)
            console.log(address)
            that.setData({
              weizhi: address
            })
          }
        });
      }
    })
  }
})
