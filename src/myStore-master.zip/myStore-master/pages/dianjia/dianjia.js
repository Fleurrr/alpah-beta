var app=getApp();
Page({
  data: {
    goodslist:[],
    goodname:[],
    shoplist:[],
    listtable:[],
    listm:[],
   allprice:0,
    shop:[],
    cart: {
      count: 0,
      total: 0,
      list: {}
    },
    showCartDetail: false
  },
  onLoad: function (options) {
    var shopId = options.bid;
    var that = this;
    
    wx.request({
      url: 'http://47.106.227.33/xejz-api/api.php?op=storelist&bid='+shopId,
      headers: {
        'Content-Type': 'application/json'
      },
     
      success: function (res) {
        that.setData({
          goodslist: res.data.result,
        })
        var o = that.data.goodslist;
        console.log(o)
        for (var i = 0; i < that.data.goodslist.length; ++i) {
          o[i].foodlist = JSON.parse(that.data.goodslist[i].foodlist)
          //console.log(o[i].foodlist)
          that.data.goodslist[i].foodlist = o[i].foodlist.result
         // console.log(that.data.goodslist[i].foodlist)
        }
        console.log(that.data.goodslist)
        that.setData({
          goodslist: o,
        })
      }

    }),
    wx.request({
      url: 'http://47.106.227.33/xejz-api/api.php?op=bfoods&bid=' + shopId,
      headers: {
        'Content-Type': 'application/json'
      },

      success: function (res) {
        
        that.setData({
          goodname: res.data.goods,

        })
        console.log(that.data.goodname)
      }
    }),
      wx.request({
      url: 'http://47.106.227.33/xejz-api/api.php?op=bstoreintro&bid='+ shopId,
        headers: {
          'Content-Type': 'application/json'
        },

        success: function (res) {
          that.setData({
            shop: res.data.result,

          })
          //console.log(that.data.shop)
        }
      })
  },

  tapAddCart: function (e) {
    this.addCart(e.target.dataset.id);
  },
  tapReduceCart: function (e) {
    this.reduceCart(e.target.dataset.id);
  },
  addCart: function (id) {
    var num = this.data.cart.list[id] || 0;
    this.data.cart.list[id] = num + 1;
    this.countCart();
  },
  reduceCart: function (id) {
    var num = this.data.cart.list[id] || 0;
    if (num <= 1) {
      delete this.data.cart.list[id];
    } else {
      this.data.cart.list[id] = num - 1;
    }
    this.countCart();
  },
  countCart: function () {
    var count = 0,

      total = 0;
    for (var id in this.data.cart.list) {
      var goods = this.data.goodname[id];
      count += this.data.cart.list[id];
      total += goods.food_price * this.data.cart.list[id];
    }
  

    this.data.cart.count = count;
    this.data.cart.total = total;
    
    this.setData({
      cart: this.data.cart,
      listtable:this.data.cart.list,
      allprice:this.data.cart.total,
    });
    console.log(this.data.listtable)
    console.log(this.data.allprice)
  },

  follow: function () {
    this.setData({
      followed: !this.data.followed
    });
  },
  tapClassify: function (e) {
    var id = e.target.dataset.id;
    console.log(id)
    this.setData({
      classifyViewed: id
    });
    var self = this;
    setTimeout(function () {
      self.setData({
        classifySeleted: id
      });
    }, 100);
  },
  showCartDetail: function () {
    this.setData({
      showCartDetail: !this.data.showCartDetail
    });
  },



  onGoodsScroll: function (e) {
    console.log("ok1")
    if (e.detail.scrollTop > 1 && !this.data.scrollDown) {
      this.setData({
        scrollDown: true
      });
    } else if (e.detail.scrollTop < 1 && this.data.scrollDown) {
      this.setData({
        scrollDown: false
      });
    }

    var scale = e.detail.scrollWidth / 570,
      scrollTop = e.detail.scrollTop / scale,
      h = 0,
      classifySeleted,
      len = this.data.goodslist.length;
    //console.log(this.data.goodname)

    this.data.goodslist.forEach(function (classify, i) {
      console.log(classify)
      var _h = 70 + classify.foodlist.length * (46 * 3 + 20 * 2);
      if (scrollTop >= h - 10 / scale) {
        classifySeleted = classify.pid;
      }
      h += _h;
    });
    this.setData({
      classifySeleted: classifySeleted
    });
    //console.log(this.data.classifySeleted)
    //console.log(this.data.classifyViewed)
  },
  tojiesuan:function(){
      wx.navigateTo({
        url: '/pages/payment/payment?listtable=' + JSON.stringify(this.data.listtable) + '&allprice=' + this.data.allprice + '&goodname=' + JSON.stringify(this.data.goodname)
      })
    }
});